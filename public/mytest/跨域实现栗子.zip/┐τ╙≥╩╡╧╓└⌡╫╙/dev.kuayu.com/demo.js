var temp = "{{each data as g i}}"
	+"<tr><td>{{ g.id}}</td><td>{{ g.goods_name}}</td><td>{{ g.price}}</td><td>{{ g.old_price}}</td>"
	+"<td>{{ g.stock}}</td><td>{{ g.denomination}}</td><td>{{ g.validity}}</td><td><img width='100' height='100' src='http://localhost:3000/{{ g.img}}'/></td>"
	+"</tr>{{/each}}";
$(function(){
	//JSONP
	$.ajax({
		url: 'http://localhost:3000/ajax_all/goods_list_jsonp',
		type: "GET",
		dataType: 'jsonp',
		jsonp: 'callback',
		data: {id:6},
		success: function (json) {
			var data = JSON.parse(json),
			list = data.data,
			render = template.compile(temp);
			$('#table1').append(render(data));
		},
		error: function(e){
			console.log(e);
		}
	});
	//Access-Control-Allow-Origin:"*/某个固定的域名"
	$.ajax({
		url: 'http://localhost:3000/ajax_all/goods_list_allow',
		type: "POST",
		data: {id:6},
		success: function (json) {
			var data = json,
			list = data.data,
			render = template.compile(temp);
			$('#table2').append(render(data));
		},
		error: function(e){
			console.log(e);
		}
	});
	//Domain iframe
	document.domain = 'kuayu.com';
	var thisIframe = document.createElement('iframe');
	thisIframe.src = 'http://api.kuayu.com/index.html',
	thisIframe.id = 'iframeCrossDomain',
	thisIframe.style.display = 'none',
	strTitle = '<table class="table table-bordered tab-pane"><tr><td>编号</td><td>名称</td><td>价格</td><td>数量</td></tr>'
	+'{{each data as d i}}<tr><td>{{d.id}}</td><td>{{d.name}}</td><td>{{d.price}}</td><td>{{d.count}}</td></tr>{{/each}}</table>',
	data = {
		url : 'data.php',
		type : 'get',
		success : function(e){
			var temp = template.compile(strTitle);
			$('#table3').html(temp(e));	
		}
		};
	$('body').append(thisIframe);
	thisIframe.onload = function(e,a){
		var win = thisIframe.contentWindow,
		doc = win.document,
		cBody = doc.getElementsByTagName('body'),
		strData = JSON.stringify(data),
		finds = $(cBody);
		finds.trigger('click',strData);
		thisIframe.onclick = function(e,a){
			if(typeof data.success === 'function'){
				data.success(a);
			}else{
				throw '请检查一下是否正确定义了success函数';	
			}
			thisIframe.remove();
		}
	};
});
//window.name    没有成功，不知道为什么？
	var iframeWindow = document.createElement('iframe');
	//http://localhost:3000/mytest/windowName.html
	iframeWindow.src = 'http://api.kuayu.com',
	iframeWindow.id = 'winName';
	iframeWindow.onload = function(){
		var iframe = document.querySelector('#winName'),
		win = iframe.contentWindow;
		//console.log(win.name);
	}
	document.body.querySelector('#table4').appendChild(iframeWindow);
//不支持IE6 ，IE7 的window.postMessage;
	var iframeWindow = document.createElement('iframe'),
	old = '';
	iframeWindow.src = 'http://localhost:3000/mytest/windowName.html';
	iframeWindow.onload = function(){
		var $this = $(this),
		param = {
			url : '/ajax_all/goods_list_post_message',
			type : 'post',
			data : {
				id : 6
				}
			};
		window.frames[1].postMessage(JSON.stringify(param),'*');
	}
	$('#table5').html(iframeWindow);
	window.onmessage = function(e){
		var ev = e || event;
		if(e.data){
			var o = JSON.parse(e.data),
			source = template.compile(temp)(o);
			$('#table5_data').append(source);
		}
	}
// location.hash 

/*function getData(url, fn) {
      var iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = url;
 
      iframe.onload = function() {
		  console.log(iframe.contentWindow.location);
        fn(iframe.contentWindow.location.hash.substring(1));
        window.location.hash = '';
        document.body.removeChild(iframe);
      };
      document.body.appendChild(iframe);
    }
    // get data from server
    var url = 'http://api.kuayu.com/hash.php';
    getData(url, function(data) {
      var jsondata = JSON.parse(data);
      console.log(jsondata.name + ' ' + jsondata.age);
    });*/