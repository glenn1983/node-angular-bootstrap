<?php
     $arr=array('code' => 1 ,'total'=>239,
		'data'=>array(
			array('id'=>'001','name'=>'摩卡','price'=>'13.8','count'=>'134'),
			array('id'=>'002','name'=>'卡布奇诺','price'=>'13.8','count'=>'354'),
			array('id'=>'003','name'=>'焦糖玛奇朵','price'=>'13.8','count'=>'678'),
			array('id'=>'004','name'=>'拿铁','price'=>'13.8','count'=>'984'),
			array('id'=>'005','name'=>'鸳鸯','price'=>'13.8','count'=>'123')
		)
      );
    echo urldecode(json_encode($arr));
?>